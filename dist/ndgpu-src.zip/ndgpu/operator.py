"""Matrix-free finite-volume diffusion operator for one energy group.

Discretizes  A phi = -div(D grad phi) + Sigma_r phi  with a cell-centered
7-point stencil. Face diffusion coefficients use the harmonic mean, which is
exact for piecewise-constant D (so heterogeneous cores are handled correctly).

The operator is deliberately matrix-free: instead of assembling a sparse
matrix, we precompute one face-coupling array per axis plus the diagonal, and
`apply()` is six shifted multiply-adds. On the GPU backend each of these is a
fused elementwise CUDA kernel over contiguous memory — this is both faster and
lighter than sparse CSR SpMV, and it keeps the entire operator on-device.

The resulting operator is symmetric positive definite as long as removal is
positive somewhere (zero-flux BC) which is what lets us use CG. On
cylindrical grids the SPD property comes from volume-weighting the equations;
``symmetric=False`` opts out of that and builds the natural divergence form
instead, which is non-symmetric and needs GMRES/BiCGStab (see ndgpu.linalg).
"""

from __future__ import annotations

import math

import numpy as np

BC_ZERO_FLUX = "zero-flux"
BC_REFLECTIVE = "reflective"
BC_VACUUM = "vacuum"

# Robin coefficient alpha in the boundary law  J_net = alpha * phi_surface
# (the leakage current out of the domain, per unit surface flux). The diffusion
# Marshak vacuum condition gives alpha = 1/2 (FEMFFUSION's bc_factor); a custom
# albedo boundary passes alpha directly. Reflective is alpha = 0 (zero current)
# and zero-flux is the alpha -> infinity (Dirichlet) limit.
_VACUUM_ALPHA = 0.5


def _face_valid(f):
    """Validate and canonicalize one face spec: a known string or an albedo."""
    if f in (BC_ZERO_FLUX, BC_REFLECTIVE, BC_VACUUM):
        return f
    try:
        alpha = float(f)
    except (TypeError, ValueError):
        raise ValueError(
            f"unknown bc {f!r}; use {BC_ZERO_FLUX!r}, {BC_REFLECTIVE!r}, "
            f"{BC_VACUUM!r}, or a non-negative albedo coefficient")
    if alpha < 0:
        raise ValueError(f"albedo coefficient must be non-negative, got {alpha}")
    return alpha


def face_alpha(spec):
    """Robin coefficient alpha for one face spec (see _VACUUM_ALPHA note)."""
    if spec == BC_REFLECTIVE:
        return 0.0
    if spec == BC_ZERO_FLUX:
        return math.inf
    if spec == BC_VACUUM:
        return _VACUUM_ALPHA
    return float(spec)


def normalize_bc(bc):
    """Expand a boundary-condition spec to ((xlo, xhi), (ylo, yhi), (zlo, zhi)).

    Accepts a single face spec (applied to all six faces), a length-3 sequence
    of per-axis entries (each a face spec or a (lo, hi) pair), or a flat
    length-6 sequence ordered x_lo, x_hi, y_lo, y_hi, z_lo, z_hi. A face spec is
    "zero-flux", "reflective", "vacuum", or a non-negative float albedo
    coefficient alpha (the boundary law J_net = alpha * phi_surface).
    """
    def is_scalar(x):
        return isinstance(x, (str, int, float))

    if is_scalar(bc):
        faces = [bc] * 6
    else:
        bc = list(bc)
        if len(bc) == 3:
            faces = []
            for axis in bc:
                pair = [axis, axis] if is_scalar(axis) else list(axis)
                if len(pair) != 2:
                    raise ValueError(f"per-axis bc must be a face spec or (lo, hi) pair, got {axis!r}")
                faces += pair
        elif len(bc) == 6:
            faces = bc
        else:
            raise ValueError(f"bc must be a face spec, 3 per-axis entries, or 6 faces, got {bc!r}")
    faces = [_face_valid(f) for f in faces]
    return ((faces[0], faces[1]), (faces[2], faces[3]), (faces[4], faces[5]))


def harmonic_mean(Da, Db):
    """Face diffusion coefficient between two cells with piecewise-constant D.

    Requiring the two-point flux to be continuous across the shared face gives
    the harmonic mean 2*Da*Db/(Da + Db): exact for piecewise-constant D, and
    it correctly chokes transport at an interface where either D vanishes
    (the arithmetic mean would leak through strong absorbers).
    """
    return 2.0 * Da * Db / (Da + Db)


def robin_face_term(xp, Dface, d, alpha):
    """Boundary-face contribution to the operator diagonal, per unit volume,
    for a face perpendicular to a cell axis with centre-to-face distance d/2.

    The Robin law J_net = alpha * phi_s relates the outward current to the
    surface flux. Coupling the cell centre to the surface with the two-point
    current J = (2D/d)(phi_c - phi_s) and eliminating phi_s gives

        leakage / volume = 2 D alpha / (d (d alpha + 2 D)).

    alpha -> inf recovers the zero-flux Dirichlet term 2D/d^2; alpha = 0
    (reflective) contributes nothing; alpha = 1/2 is the Marshak vacuum.
    """
    if alpha == 0.0:
        return xp.zeros_like(Dface)
    if math.isinf(alpha):
        return 2.0 * Dface / d**2
    return 2.0 * Dface * alpha / (d * (d * alpha + 2.0 * Dface))


class GroupOperator:
    """A_g = -div(D_g grad .) + Sigma_r,g  on a uniform structured grid.

    Cartesian by default; a grid with geometry="cylindrical" yields the (r-z)
    revolution-body stencil instead (volume-weighted form; pair the operator
    with a source scaled by .rhs_weight, which is None on Cartesian grids).

    Parameters
    ----------
    xp        : array module (numpy or cupy)
    grid      : Grid
    D         : per-cell diffusion coefficient, shape grid.shape (device array)
    removal   : per-cell removal cross section, shape grid.shape (device array)
    bc        : boundary conditions, anything accepted by normalize_bc():
                "zero-flux" (phi = 0 on the outer boundary surface) or
                "reflective" (zero net current), globally, per axis, or per face.
    symmetric : cylindrical grids only. True (default) builds the
                volume-weighted form, which is SPD and pairs with CG plus a
                source scaled by .rhs_weight. False builds the natural
                divergence (per-unit-volume) form instead: the same equations
                with each row divided by its cell volume, so the source is
                used as-is (.rhs_weight is None) -- but the radial coupling
                seen from cell i (r_face/r_i) no longer equals its transpose
                (r_face/r_{i+1}), so the matrix is non-symmetric and must be
                paired with linear_solver="gmres" or "bicgstab", not CG.
                Ignored on Cartesian grids (already symmetric either way).
    """

    def __init__(self, xp, grid, D, removal, bc=BC_ZERO_FLUX, active=None,
                 mask_bc=BC_VACUUM, symmetric=True):
        bc = normalize_bc(bc)
        self.xp = xp
        self.shape = grid.shape
        dx, dy, dz = grid.spacing

        # Cylindrical (r-z) grids: every term of the per-unit-volume Cartesian
        # stencil is scaled by its radial metric factor -- cell terms (removal,
        # y/z couplings, y/z boundary faces) by the cell-center radius cw, and
        # radial face terms by the face radius. This is the equation multiplied
        # by the cell volume, so the radial two-point stencil stays symmetric
        # (both neighbours see the shared face radius) and CG still applies;
        # the matching source-side weight is exposed as self.rhs_weight. On a
        # Cartesian grid all factors are 1 and the stencil is unchanged.
        met = getattr(grid, "cylindrical_metrics", lambda: None)()
        if met is None:
            cw = fwx = 1.0
            bwx_lo = bwx_hi = 1.0
            self.rhs_weight = None
        else:
            rc, rf, r_lo, r_hi = met
            cw = xp.asarray(rc, dtype=D.dtype)
            fwx = xp.asarray(rf, dtype=D.dtype)
            bwx_lo, bwx_hi = float(r_lo), float(r_hi)
            self.rhs_weight = cw

        def robin(Dface, d, alpha):
            return robin_face_term(xp, Dface, d, alpha)

        # Interior face couplings (harmonic mean of the two adjacent cells).
        # wx[i] couples cells i and i+1 along x; shape (nx-1, ny, nz).
        def face(Da, Db, d):
            return harmonic_mean(Da, Db) / (d * d)

        self.wx = fwx * face(D[:-1, :, :], D[1:, :, :], dx)
        self.wy = cw * face(D[:, :-1, :], D[:, 1:, :], dy)
        self.wz = cw * face(D[:, :, :-1], D[:, :, 1:], dz)

        # Non-rectangular cores: an "active" mask marks in-domain cells. Faces
        # touching an inactive (excised) cell carry no diffusion; the active
        # cell instead sees the core-surface boundary law mask_bc on that face.
        act = None
        if active is not None:
            act = xp.asarray(active).astype(bool)
            if act.shape != grid.shape:
                raise ValueError(f"active mask shape {act.shape} != grid shape {grid.shape}")
            self.wx = xp.where(act[:-1, :, :] & act[1:, :, :], self.wx, 0.0)
            self.wy = xp.where(act[:, :-1, :] & act[:, 1:, :], self.wy, 0.0)
            self.wz = xp.where(act[:, :, :-1] & act[:, :, 1:], self.wz, 0.0)

        # Diagonal: removal + sum of face couplings incident on each cell.
        diag = removal * cw
        diag[1:, :, :] += self.wx
        diag[:-1, :, :] += self.wx
        diag[:, 1:, :] += self.wy
        diag[:, :-1, :] += self.wy
        diag[:, :, 1:] += self.wz
        diag[:, :, :-1] += self.wz

        # Outer box-boundary Robin terms (only where the boundary cell is
        # active), each scaled by its face's metric weight: the boundary radius
        # for the two radial faces (0 at the symmetry axis, so any bc there is
        # inert), the cell radius for y/z faces.
        cw_at = (lambda sl: 1.0) if met is None else (lambda sl: cw[sl])
        boundary_faces = [
            (face_alpha(bc[0][0]), (0, slice(None), slice(None)), dx, lambda sl: bwx_lo),
            (face_alpha(bc[0][1]), (-1, slice(None), slice(None)), dx, lambda sl: bwx_hi),
            (face_alpha(bc[1][0]), (slice(None), 0, slice(None)), dy, cw_at),
            (face_alpha(bc[1][1]), (slice(None), -1, slice(None)), dy, cw_at),
            (face_alpha(bc[2][0]), (slice(None), slice(None), 0), dz, cw_at),
            (face_alpha(bc[2][1]), (slice(None), slice(None), -1), dz, cw_at),
        ]
        for alpha, sl, d, wgt in boundary_faces:
            if alpha == 0.0:
                continue
            term = wgt(sl) * robin(D[sl], d, alpha)
            if act is not None:
                term = xp.where(act[sl], term, 0.0)
            diag[sl] += term

        # Internal core-surface faces (active cell facing an excised cell).
        if act is not None:
            ma = face_alpha(_face_valid(mask_bc))
            if ma != 0.0:
                lo_a, hi_a = act[:-1, :, :], act[1:, :, :]
                diag[:-1, :, :] += xp.where(lo_a & ~hi_a, fwx * robin(D[:-1, :, :], dx, ma), 0.0)
                diag[1:, :, :] += xp.where(hi_a & ~lo_a, fwx * robin(D[1:, :, :], dx, ma), 0.0)
                lo_a, hi_a = act[:, :-1, :], act[:, 1:, :]
                diag[:, :-1, :] += xp.where(lo_a & ~hi_a, cw * robin(D[:, :-1, :], dy, ma), 0.0)
                diag[:, 1:, :] += xp.where(hi_a & ~lo_a, cw * robin(D[:, 1:, :], dy, ma), 0.0)
                lo_a, hi_a = act[:, :, :-1], act[:, :, 1:]
                diag[:, :, :-1] += xp.where(lo_a & ~hi_a, cw * robin(D[:, :, :-1], dz, ma), 0.0)
                diag[:, :, 1:] += xp.where(hi_a & ~lo_a, cw * robin(D[:, :, 1:], dz, ma), 0.0)
            # Excised cells: decouple (all face weights into them are already 0)
            # and give them a unit diagonal so Jacobi is well defined; with a
            # void material (no fission/scatter) their flux stays exactly zero.
            diag = xp.where(act, diag, 1.0)

        # Divergence form (symmetric=False, cylindrical only): apply() runs
        # the weighted stencil and then divides each row by its cell weight,
        # which is exactly the matrix W^{-1} A_w -- the classic non-symmetric
        # finite-volume form. The Jacobi diagonal scales along.
        self._stencil_diag = diag
        self.row_scale = None
        if not symmetric and met is not None:
            self.row_scale = 1.0 / cw
            self.rhs_weight = None
            diag = diag * self.row_scale
        self.diag = diag
        self.inv_diag = 1.0 / diag  # Jacobi preconditioner

    def apply(self, phi):
        """Return A phi (allocates the output array)."""
        out = self._stencil_diag * phi
        out[1:, :, :] -= self.wx * phi[:-1, :, :]
        out[:-1, :, :] -= self.wx * phi[1:, :, :]
        out[:, 1:, :] -= self.wy * phi[:, :-1, :]
        out[:, :-1, :] -= self.wy * phi[:, 1:, :]
        out[:, :, 1:] -= self.wz * phi[:, :, :-1]
        out[:, :, :-1] -= self.wz * phi[:, :, 1:]
        if self.row_scale is not None:
            out *= self.row_scale
        return out


class SP3GroupOperator:
    """Symmetrized within-group SP3 / SDP1 block operator (``variant=``).

    The SP3 equations for one group, in the moments Phi1 = phi0 + 2*phi2 and
    phi2 (Brantley & Larsen form, isotropic sources):

        -div(D1 grad Phi1) + Sig0 * Phi1 - 2*Sig0 * phi2            = q0
        -div(D2 grad phi2) + (Sig2 + 4/5*Sig0) * phi2
                           - 2/5*Sig0 * Phi1                        = -2/5 q0

    with D1 = 1/(3*Sig1), D2 = 9/(35*Sig3), Sig0 the group removal cross
    section and Sig_l = Sigma_t - Sigma_s,l (here Sig1 uses the
    transport-corrected total via the material's D, and Sig2 = Sig3 = Sigma_t
    since l >= 2 scattering moments are not part of the data model).

    Multiplying the second equation by 5 makes the 2x2 block system symmetric
    (off-diagonal blocks both -2*Sig0) and positive definite
    (5*Sig0*Sig2 > 0), so the coupled system is solved directly by CG on
    states of shape (2, nx, ny, nz). The scalar flux is phi0 = Phi1 - 2*phi2.

    Boundary conditions: "reflective" is exact for SPN; "zero-flux" imposes
    phi = 0 on the surface for both moments (a good approximation whenever the
    physical vacuum boundary sits behind a reflector; Marshak vacuum
    conditions, which couple the moments at the boundary, are not implemented).

    The spatial discretization of both moment operators is supplied by
    ``op_cls`` (default :class:`GroupOperator`, the structured Cartesian
    stencil). Passing a compatible operator -- e.g. the triangular
    ``TriGroupOperator`` -- yields SP3 on that geometry with no change to the
    angular block: the SP3 coupling only cares that ``op_cls`` exposes
    ``apply`` and ``inv_diag`` and accepts (xp, grid, D, removal, bc, active,
    mask_bc).
    """

    def __init__(self, xp, grid, D1, sigma_t, removal, bc=BC_ZERO_FLUX,
                 active=None, mask_bc=BC_VACUUM, op_cls=None, variant="sp3",
                 theta=None):
        self.xp = xp
        op_cls = op_cls or GroupOperator
        # Time-dependent term: a backward-Euler step adds theta = 1/(v*dt) times
        # the moments' time derivatives, with the odd-moment time derivatives
        # neglected (the standard quasi-static closure of time-SP3 kinetics).
        # Row 0 is the phi0 balance, so it carries theta*(Phi1 - 2 phi2): the
        # Phi1 diagonal *and* the phi2 coupling of row 0 both pick up theta.
        # Row 1 is NOT just theta*phi2: eliminating the odd moments substitutes
        # the balance equation into the second-moment equation, dragging in
        # -(2/5) d(phi0)/dt -- the exact row-1 time term (in this 5x-scaled row)
        # is theta*(9 phi2 - 2 Phi1). Equivalently, in the U-form the time
        # matrix is theta * sum_m c^(m) = theta*[[1,-2/3],[-2/3,1]] (identical
        # for SP3 and SDP1), which is non-diagonal but symmetric -- see the
        # sympy derivation in tests/verification/test_sdpn_derivation.py.
        # theta=None -> steady.
        m1_removal = removal if theta is None else removal + theta
        self.moment1 = op_cls(xp, grid, D1, m1_removal, bc=bc,
                              active=active, mask_bc=mask_bc)
        # The "sdp1" variant is the simplified double-P1 approximation of
        # Carreno, Vidal-Ferrandiz, Ginestar & Verdu, Ann. Nucl. Energy 207
        # (2024) 110675. Working their Eqs. (39)-(40) into these same moments
        # (Phi1 = phi0 + 2 phi2, phi2) gives a moment-1 equation *identical* to
        # SP3 and a moment-2 equation with the identical reaction
        # (Sig2 + 4/5 Sig0), coupling (2 Sig0) and RHS -- the sole difference
        # is the second-moment diffusion coefficient:
        #   "sp3"  -> D2 = 9/(35 Sigma_3)   (Brantley & Larsen simplified P3)
        #   "sdp1" -> D2 = 1/(5  Sigma_3)   (= 7/9 of the SP3 value)
        # Built from the half-range (double-PN) angular expansion, SDP1 tracks
        # discontinuous angular flux better than SP3 at the same cost, so it is
        # more accurate across strongly heterogeneous media (steep flux
        # gradients at water gaps / strong absorbers) -- see the paper's 1D BWR
        # results, where SDP1 beats SP3 for equal degrees of freedom.
        if variant == "sp3":
            D2 = 9.0 / (35.0 * sigma_t)
        elif variant == "sdp1":
            D2 = 1.0 / (5.0 * sigma_t)
        else:
            raise ValueError(f"variant must be 'sp3' or 'sdp1', got {variant!r}")
        self.variant = variant
        m2_reaction = sigma_t + 0.8 * removal
        if theta is not None:
            # 5x-scaled row 1 carries 9*theta*phi2 -> 9/5 on the unscaled row.
            m2_reaction = m2_reaction + 1.8 * theta
        self.moment2 = op_cls(xp, grid, D2, m2_reaction, bc=bc,
                              active=active, mask_bc=mask_bc)
        # The moment-coupling term is a cell (volume) term, so it carries the
        # same metric weight as the moment operators' removal (1 on Cartesian).
        w = getattr(self.moment1, "rhs_weight", None)
        wt = 1.0 if w is None else w
        # Row-0 phi2 coupling picks up theta (the -2 theta phi2 half of
        # theta*phi0) and row-1's Phi1 coupling picks up the -2 theta Phi1 half
        # of its time term (see the theta note above): the exact time matrix is
        # symmetric, so the transient block stays symmetric (and SPD -- the
        # scaled time matrix [[1,-2],[-2,9]] is positive definite), and CG
        # still applies.
        c = 2.0 * removal if theta is None else 2.0 * (removal + theta)
        self.coupling = c * wt
        self.coupling_t = c * wt
        self.theta = theta
        self.rhs_weight = w
        self.inv_diag = xp.stack([self.moment1.inv_diag, self.moment2.inv_diag / 5.0])

    def apply(self, u):
        """Return the block operator applied to u = (Phi1, phi2)."""
        out = self.xp.empty_like(u)
        out[0] = self.moment1.apply(u[0]) - self.coupling * u[1]
        out[1] = 5.0 * self.moment2.apply(u[1]) - self.coupling_t * u[0]
        return out


class CongruentSDPNOperator:
    """Order-N SDPN block in a symmetrizing congruence basis (V = S^-1 U) --
    the CG path for tables with no diagonal similarity (SDP3).

    The transformed gradient block couples moments, but it is a sum of two
    low-rank constant matrices times scalar fields (D_1 and 1/Sigma_t), so its
    eigen-decomposition reduces the apply to one scalar stencil per retained
    eigenpair -- M stencil applies in total, the same count as the plain
    per-moment form. Reactions are M x M symmetric cell couplings. All pieces
    are PSD (verified at transform construction), so the block is SPD.

    Only reflective / zero-flux faces are supported: they impose the same
    condition on every moment and therefore commute with the moment mixing
    (the projected variables inherit the identical scalar boundary term). The
    per-moment vacuum Robin term is moment-dependent and does not, so vacuum
    problems keep the plain non-symmetric form. Cartesian/tri grids only (no
    cylindrical metric weighting).
    """

    _ALLOWED = (BC_REFLECTIVE, BC_ZERO_FLUX)

    def __init__(self, xp, grid, D1, sigma_t, removal, order, bc=BC_ZERO_FLUX,
                 active=None, mask_bc=BC_VACUUM, op_cls=None, coeffs=None,
                 theta=None):
        tr = _congruence_transform(order, coeffs)
        if tr is None:
            raise ValueError(f"order-{order} tables admit no symmetrizing "
                             "congruence")
        if getattr(grid, "cylindrical_metrics", lambda: None)() is not None:
            raise NotImplementedError("congruence path is not implemented for "
                                      "cylindrical grids")
        bc_n = normalize_bc(bc)
        faces = [f for axis in bc_n for f in axis]
        if any(f not in self._ALLOWED for f in faces):
            raise ValueError("the symmetrized SDP3 block supports only "
                             "reflective/zero-flux faces (vacuum Robin is "
                             "moment-dependent and breaks the symmetry); got "
                             f"{bc_n!r}")
        if active is not None and mask_bc not in self._ALLOWED:
            raise ValueError("active masks need mask_bc reflective/zero-flux "
                             "on the symmetrized SDP3 block")
        self.xp = xp
        op_cls = op_cls or GroupOperator
        M = order + 1
        self.M = M
        self.order = order
        self.symmetric = True
        self.marshak = None
        self.rhs_weight = None
        self.src_weights = [float(w) for w in tr["src"]]
        self.phi0_weights = [float(w) for w in tr["phi0"]]
        self.time_weights = [[float(tr["tau"][i][j]) for j in range(M)]
                             for i in range(M)]
        zero = xp.zeros(grid.shape, dtype=D1.dtype)
        # Projected scalar leakage operators: (weights w, op on lam*field).
        self._proj = []
        for field, pairs in ((D1, tr["grad_tr"]),
                             (1.0 / sigma_t, tr["grad_t"])):
            for lam, w in pairs:
                L = op_cls(xp, grid, lam * field, zero, bc=bc_n,
                           active=active, mask_bc=mask_bc)
                self._proj.append(([float(x) for x in w], L))
        c1, ct = tr["c1"], tr["ct"]
        # Pre-combined per-pair reaction fields: apply adds R_ij * u_j with
        # R_ij = c1_ij removal + ct_ij sigma_t (+ theta tau_ij) -- one fused
        # multiply-add per (i, j) instead of two or three (measurably cheaper:
        # the reactions are dense M x M after the congruence).
        self._react = {}
        for i in range(M):
            for j in range(M):
                a, b = c1[i][j], ct[i][j]
                t = 0.0 if theta is None else theta * self.time_weights[i][j]
                if a == 0.0 and b == 0.0 and t == 0.0:
                    continue
                self._react[(i, j)] = a * removal + b * sigma_t + t
        diag = xp.zeros((M,) + grid.shape, dtype=D1.dtype)
        for w, L in self._proj:
            for i in range(M):
                if w[i] != 0.0:
                    diag[i] += (w[i] * w[i]) * L.diag
        for i in range(M):
            if (i, i) in self._react:
                diag[i] += self._react[(i, i)]
        self.inv_diag = 1.0 / diag

    def apply(self, u):
        """Return the symmetrized block applied to u of shape (M, *grid)."""
        xp = self.xp
        M = self.M
        out = xp.zeros_like(u)
        for w, L in self._proj:
            s = None
            for i in range(M):
                if w[i] != 0.0:
                    s = w[i] * u[i] if s is None else s + w[i] * u[i]
            Ls = L.apply(s)
            for i in range(M):
                if w[i] != 0.0:
                    out[i] += w[i] * Ls
        for (i, j), f in self._react.items():
            out[i] += f * u[j]
        return out


# Simplified double-PN (SDPN) coefficient matrices c^(m), from Carreno,
# Vidal-Ferrandiz, Ginestar & Verdu, Ann. Nucl. Energy 207 (2024) 110675,
# Eqs. (43) [SDP1] and (A.3)/(A.6) [SDP2/SDP3]. For angular order N the block
# carries M = N + 1 even-moment pseudo-fluxes U_1..U_M and the diffusive system
#     -div(D grad U) + A U = (1/k) F U,
# with D_i = 1/((4i-1) Sigma_{2i-1}),  A_ij = sum_{m=1..M} c^(m)_ij Sigma_{2m-2},
# and F_ij = c^(1)_ij F. Only the last (closure) row of each c^(m) differs from
# the standard SPN coefficients -- that row is the half-range (double-PN)
# correction that lets SDPN track discontinuous angular flux better than SPN at
# equal cost. c^(m)[N] indexes the m-th matrix (m = 1..M) for order N.
_SDPN_C = {
    1: [
        [[1.0, -2.0 / 3.0], [-6.0 / 7.0, 4.0 / 7.0]],
        [[0.0, 0.0], [0.0, 5.0 / 7.0]],
    ],
    2: [
        # c^(1) must be rank-1 (fission depends only on phi0): row i = c1[i][0]
        # * row0. The paper's printed (A.3) third row [-32/33, -64/99, 256/495]
        # violates this: the first entry's sign is a typo -- with +32/33 the row
        # is exactly (32/33)*row0 = [32/33, -64/99, 256/495], rank-1, and
        # reproduces the paper's SDP2 k_eff (Table 6). Verified on the Fig. 3
        # Brantley-Larsen problem (examples/sdpn_brantley_larsen_2d.py).
        [[1.0, -2.0 / 3.0, 8.0 / 15.0],
         [-2.0 / 3.0, 4.0 / 9.0, -16.0 / 45.0],
         [32.0 / 33.0, -64.0 / 99.0, 256.0 / 495.0]],
        [[0.0, 0.0, 0.0],
         [0.0, 5.0 / 9.0, -4.0 / 9.0],
         [0.0, -80.0 / 99.0, 64.0 / 99.0]],
        [[0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0],
         [0.0, 0.0, 36.0 / 55.0]],
    ],
    # SDP3: rows 0-1 match the paper's (A.6); rows 2-3 are re-derived from
    # scratch (sympy, from the paper's own Eq. (34) DPN closure -- half-range
    # moments of the PN system truncated at l = 2N+1, odd moments eliminated,
    # U-transform of Eq. (13), D = diag(1/3, 1/7, 1/11, 1/15) Sigma^-1). The
    # derivation machinery reproduces the paper's SDP1 and SDP2 tables (and the
    # SDP3 Marshak g of (A.7)) exactly, but NOT its printed SDP3 rows 2-3 --
    # which also appear verbatim in the authors' FEMFFUSION code and look like a
    # transcription chimera (c^(1)/c^(2) row 2 are the SP7 rows, c^(3) row 2
    # carries SDP2's closure value 36/55). Note the true c^(4) has a nonzero
    # (2,3) entry, absent from the paper's sparsity pattern. On the paper's
    # Fig. 3 benchmark these tables give k = 0.80394 vs the published 0.80402
    # (-9 pcm); the paper's own tables give +24 pcm.
    3: [
        [[1.0, -2.0 / 3.0, 8.0 / 15.0, -16.0 / 35.0],
         [-2.0 / 3.0, 4.0 / 9.0, -16.0 / 45.0, 32.0 / 105.0],
         [200.0 / 429.0, -400.0 / 1287.0, 320.0 / 1287.0, -640.0 / 3003.0],
         [-16.0 / 13.0, 32.0 / 39.0, -128.0 / 195.0, 256.0 / 455.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 5.0 / 9.0, -4.0 / 9.0, 8.0 / 21.0],
         [0.0, -500.0 / 1287.0, 400.0 / 1287.0, -800.0 / 3003.0],
         [0.0, 40.0 / 39.0, -32.0 / 39.0, 64.0 / 91.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 45.0 / 143.0, -270.0 / 1001.0],
         [0.0, 0.0, -54.0 / 65.0, 324.0 / 455.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 3.0 / 77.0],
         [0.0, 0.0, 0.0, 5.0 / 7.0]],
    ],
}

# Standard SPN coefficient matrices c^(m), from the same paper's Eqs. (16)-(17)
# (order 1/2/3 = SP3/SP5/SP7, obtained by truncating the SP7 matrices). Same
# U-form and D block as SDPN above -- the two families differ *only* in these
# coefficients (and SDPN only in each matrix's last, closure, row). Unlike SDPN,
# every c^(m) here is symmetric, so the SPN block operator is symmetric.
_SPN_C = {
    # Order 0 = SP1: one moment, U = phi0, A = removal, D = 1/(3 Sigma_1) --
    # the plain P1/diffusion equation run through the same block machinery.
    0: [[[1.0]]],
    1: [
        [[1.0, -2.0 / 3.0], [-2.0 / 3.0, 4.0 / 9.0]],
        [[0.0, 0.0], [0.0, 5.0 / 9.0]],
    ],
    2: [
        [[1.0, -2.0 / 3.0, 8.0 / 15.0],
         [-2.0 / 3.0, 4.0 / 9.0, -16.0 / 45.0],
         [8.0 / 15.0, -16.0 / 45.0, 64.0 / 225.0]],
        [[0.0, 0.0, 0.0],
         [0.0, 5.0 / 9.0, -4.0 / 9.0],
         [0.0, -4.0 / 9.0, 16.0 / 45.0]],
        [[0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0],
         [0.0, 0.0, 9.0 / 25.0]],
    ],
    3: [
        [[1.0, -2.0 / 3.0, 8.0 / 15.0, -16.0 / 35.0],
         [-2.0 / 3.0, 4.0 / 9.0, -16.0 / 45.0, 32.0 / 105.0],
         [8.0 / 15.0, -16.0 / 45.0, 64.0 / 225.0, -128.0 / 525.0],
         [-16.0 / 35.0, 32.0 / 105.0, -128.0 / 525.0, 256.0 / 1225.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 5.0 / 9.0, -4.0 / 9.0, 8.0 / 21.0],
         [0.0, -4.0 / 9.0, 16.0 / 45.0, -32.0 / 105.0],
         [0.0, 8.0 / 21.0, -32.0 / 105.0, 64.0 / 245.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 9.0 / 25.0, -54.0 / 175.0],
         [0.0, 0.0, -54.0 / 175.0, 324.0 / 1225.0]],
        [[0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 0.0],
         [0.0, 0.0, 0.0, 13.0 / 49.0]],
    ],
}

# Marshak vacuum boundary matrices g (B = g (x) I over groups) for the coupled
# condition -n . D grad U = B U, from the same paper: SPN in Eq. (23) [SP7, with
# the lower orders its leading submatrices], SDPN in Eqs. (47)/(A.4)/(A.7). g_11
# = 1/2 is the standard 0th-moment Marshak value; the off-diagonals couple the
# moments at the boundary (the piece a per-moment albedo omits). SPN g is
# symmetric, SDPN g is not.
_SPN_G = {
    3: [[1.0 / 2, -1.0 / 8, 1.0 / 16, -5.0 / 128],
        [-1.0 / 8, 7.0 / 24, -41.0 / 384, 1.0 / 16],
        [1.0 / 16, -41.0 / 384, 407.0 / 1920, -233.0 / 2560],
        [-5.0 / 128, 1.0 / 16, -233.0 / 2560, 3023.0 / 17920]],
}
_SPN_G[0] = [row[:1] for row in _SPN_G[3][:1]]   # SP1: the classic alpha = 1/2
_SPN_G[1] = [row[:2] for row in _SPN_G[3][:2]]
_SPN_G[2] = [row[:3] for row in _SPN_G[3][:3]]
_SDPN_G = {
    1: [[1.0 / 2, -1.0 / 8], [-2.0 / 7, 23.0 / 42]],
    2: [[1.0 / 2, -1.0 / 8, 1.0 / 16],
        [-2.0 / 21, 31.0 / 126, -59.0 / 1260],
        [8.0 / 33, -38.0 / 99, 287.0 / 495]],
    3: [[1.0 / 2, -1.0 / 8, 1.0 / 16, -5.0 / 128],
        [-1.0 / 8, 7.0 / 24, -41.0 / 384, 1.0 / 16],
        [-2.0 / 143, 4.0 / 429, 1087.0 / 17160, 3611.0 / 40040],
        [-10.0 / 39, 46.0 / 117, -2417.0 / 4680, 1891.0 / 2730]],
}


def _diag_similarity(c):
    """Diagonal similarity r with r_i c^(m)_ij / r_j symmetric for EVERY m, or
    None when the tables admit none. Determined by the rank-1 c^(1) = u v^T:
    the symmetry condition (r_i/r_j)^2 = c_ji/c_ij gives r_i = sqrt(v_i/u_i);
    the remaining c^(m) are then verified. Already-symmetric tables (SPN)
    yield the identity. SDP1/SDP2 admit one; SDP3 does not (its c^(4) has
    (2,3) = 3/77 against (3,2) = 0, which no scaling can bridge)."""
    M = len(c[0])
    u = [c[0][i][0] for i in range(M)]
    v = [c[0][0][j] for j in range(M)]
    if any(ui * vi <= 0.0 for ui, vi in zip(u, v)):
        return None
    r = [(vi / ui) ** 0.5 for ui, vi in zip(u, v)]
    for m in range(M):
        for i in range(M):
            for j in range(M):
                a = r[i] * c[m][i][j] / r[j]
                b = r[j] * c[m][j][i] / r[i]
                if abs(a - b) > 1e-12 * (abs(a) + abs(b) + 1e-300):
                    return None
    return r


_CONGRUENCE_CACHE = {}


def _congruence_transform(order, coeffs=None):
    """Constant congruence (R, S) symmetrizing the order-N SDPN block in
    ndgpu's collapsed data model (Sigma_2 = Sigma_3 = ... = Sigma_t), for
    tables that admit NO diagonal similarity (SDP3).

    The block is built from four constant matrices paired with two spatial
    fields: gradients D_1(x)*e1e1^T + (1/Sigma_t)(x)*diag(0, kappa_2..) and
    reactions Sigma_0(x)*c^(1) + Sigma_t(x)*sum_{m>=2} c^(m). A transform
    R P S making all four symmetric exists iff the linear system
    H T_k = T_k^T H (T_k = P_k Q^-1, Q the invertible gradient anchor) has an
    SPD solution H; then R = H^(1/2), S = Q^-1 H^(-1/2). For SDP3 the solution
    space is one-dimensional and definite, and every transformed piece comes
    out PSD, so the block is SPD and CG applies. Returns a dict of the
    transformed pieces (or None): projection eigenpairs of the two gradient
    matrices, reaction matrices, time matrix, and source/flux weights.
    """
    key = (order, id(coeffs) if coeffs is not None else None)
    if key in _CONGRUENCE_CACHE:
        return _CONGRUENCE_CACHE[key]
    c = (coeffs if coeffs is not None else _SDPN_C)[order]
    M = order + 1
    c1 = np.array(c[0], float)
    Ct = sum(np.array(cm, float) for cm in c[1:])
    kap = np.diag([0.0] + [1.0 / (4 * (i + 1) - 1) for i in range(1, M)])
    e11 = np.zeros((M, M)); e11[0, 0] = 1.0
    Q = e11 + kap
    pieces = [e11, kap, c1, Ct]
    Ts = [P @ np.linalg.inv(Q) for P in pieces]
    # solve H T = T^T H over symmetric H (linear; null space by SVD)
    idx = [(i, j) for i in range(M) for j in range(i, M)]
    A = np.zeros((len(Ts) * (M * (M - 1) // 2), len(idx)))
    for a, (i, j) in enumerate(idx):
        Hb = np.zeros((M, M)); Hb[i, j] = Hb[j, i] = 1.0
        r = 0
        for T in Ts:
            C = Hb @ T - T.T @ Hb
            A[r:r + M * (M - 1) // 2, a] = C[np.triu_indices(M, 1)]
            r += M * (M - 1) // 2
    _, sv, vt = np.linalg.svd(A)
    nnull = len(idx) - int(np.sum(sv > 1e-12 * max(sv[0], 1.0)))
    result = None
    for v in (vt[-nnull:] if nnull else []):
        H = np.zeros((M, M))
        for a, (i, j) in enumerate(idx):
            H[i, j] = H[j, i] = v[a]
        ev = np.linalg.eigvalsh(H)
        if ev[-1] < 0:
            H, ev = -H, -ev[::-1]
        if ev[0] <= 1e-10 * ev[-1]:
            continue                                  # not definite
        lam, W = np.linalg.eigh(H)
        R = W @ np.diag(np.sqrt(lam)) @ W.T
        S = np.linalg.inv(Q) @ (W @ np.diag(1.0 / np.sqrt(lam)) @ W.T)
        sym = lambda P: 0.5 * ((R @ P @ S) + (R @ P @ S).T)
        M1, M2, C1p, Ctp = sym(e11), sym(kap), sym(c1), sym(Ct)
        if min(np.linalg.eigvalsh(P)[0] for P in (M1, M2, C1p, Ctp)) < -1e-10:
            continue                                  # needs PSD pieces
        def eigpairs(P):
            lam_p, W_p = np.linalg.eigh(P)
            keep = lam_p > 1e-12 * max(lam_p.max(), 1.0)
            return [(float(l), W_p[:, k].copy())
                    for k, l in enumerate(lam_p) if keep[k]]
        result = {
            "grad_tr": eigpairs(M1),      # pairs (lambda, w) on the D1 field
            "grad_t": eigpairs(M2),       # pairs on the 1/Sigma_t field
            "c1": C1p, "ct": Ctp, "tau": C1p + Ctp,
            "src": R @ c1[:, 0], "phi0": S.T @ c1[0],
            "R": R, "S": S,
        }
        break
    _CONGRUENCE_CACHE[key] = result
    return result


def _strip_vacuum(bc):
    """Replace vacuum faces with reflective (their leakage is taken over by the
    coupled Marshak boundary); other faces are unchanged. bc is normalized."""
    return tuple(tuple(BC_REFLECTIVE if f == BC_VACUUM else f for f in axis)
                 for axis in bc)


def _congruence_available(order, grid, bc, active, mask_bc, coeffs=None):
    """True when :class:`CongruentSDPNOperator` can serve this problem: the
    order's tables admit the symmetrizing congruence AND every boundary the
    operator will see -- the six faces plus the active-mask boundary, if any --
    is reflective or zero-flux (the class's restrictions; see its docstring).
    The solvers use this to auto-select the CG path per problem."""
    if _congruence_transform(order, coeffs) is None:
        return False
    if grid is None or getattr(grid, "cylindrical_metrics", lambda: None)() is not None:
        return False
    try:
        faces = [f for axis in normalize_bc(bc) for f in axis]
    except ValueError:
        return False
    allowed = CongruentSDPNOperator._ALLOWED
    if any(f not in allowed for f in faces):
        return False
    if active is not None and mask_bc not in allowed:
        return False
    return True


def _marshak_faces(xp, grid, bc, D_list, g):
    """Precompute, for each vacuum face, the per-boundary-cell coupling matrix
    K (shape (*slab, M, M)) of the Marshak condition -n.D grad U = (g (x) I) U.

    With the two-point boundary current J_i = (2 D_i/d)(U_c,i - U_s,i) and
    J_i = sum_j g_ij U_s,j, eliminating the surface value U_s gives the leakage
    per unit volume K = (1/d) g (diag(a) + g)^-1 diag(a), a_i = 2 D_i/d. For one
    moment this is exactly robin_face_term with alpha = g_00. Cartesian only.
    """
    if getattr(grid, "cylindrical_metrics", lambda: None)() is not None:
        raise NotImplementedError("Marshak vacuum not implemented for cylindrical grids")
    M = len(D_list)
    gm = xp.asarray(g, dtype=D_list[0].dtype)                # (M, M)
    dx, dy, dz = grid.spacing
    spacing = (dx, dy, dz)
    faces = [(0, (0, slice(None), slice(None))), (0, (-1, slice(None), slice(None))),
             (1, (slice(None), 0, slice(None))), (1, (slice(None), -1, slice(None))),
             (2, (slice(None), slice(None), 0)), (2, (slice(None), slice(None), -1))]
    specs = [bc[0][0], bc[0][1], bc[1][0], bc[1][1], bc[2][0], bc[2][1]]
    out = []
    eye = xp.eye(M, dtype=gm.dtype)
    for (axis, sl), spec in zip(faces, specs):
        if spec != BC_VACUUM:
            continue
        d = spacing[axis]
        # a_i on the boundary layer, moved to a trailing moment axis: (*slab, M).
        a = xp.stack([2.0 * D_list[i][sl] / d for i in range(M)], axis=-1)
        Mmat = gm + a[..., None] * eye                       # diag(a) + g, (*slab,M,M)
        Minv = xp.linalg.inv(Mmat)
        gMinv = xp.matmul(gm, Minv)                          # (*slab,M,M)
        K = (1.0 / d) * gMinv * a[..., None, :]              # K_ij = (1/d) a_j (gMinv)_ij
        out.append((sl, K))
    return out


class SDPNGroupOperator:
    """Within-group simplified double-PN (SDPN) block operator, order N in
    {1, 2, 3} (M = N+1 moments), in the paper's diffusive U-form.

    Row i of the block is a diffusion-like operator on pseudo-moment U_i coupled
    to the others only through cell (reaction) terms:

        [op(U)]_i = -div(D_i grad U_i) + sum_j A_ij U_j,

    with D_i = 1/((4i-1) Sigma_{2i-1}) (D_1 is the transport-corrected group
    diffusion coefficient; Sigma_3 = Sigma_5 = Sigma_7 = Sigma_t in the isotropic
    data model) and A_ij = sum_m c^(m)_ij Sigma_{2m-2} (Sigma_0 = removal, the
    higher even removals = Sigma_t). The coefficient matrices c^(m) are
    :data:`_SDPN_C`.

    The same class serves the standard SPN family (``coeffs=_SPN_C``): the block
    structure, D and source/flux wiring are identical -- only the c^(m) matrices
    change. For SDPN the coupling matrix A is non-symmetric (the double-PN
    closure breaks the SPN symmetry), so the block is solved with BiCGStab/GMRES
    rather than CG; the SPN coefficients are symmetric. Group coupling
    (in-scatter, fission) is isotropic and enters only the phi0 moment; the
    driver distributes the scalar source over rows by the first column of c^(1)
    (``src_weights``), and the scalar flux is recovered as phi0 = c^(1)[0] . U
    (``phi0_weights``). Any ``op_cls`` exposing GroupOperator's (apply, inv_diag)
    interface supplies the per-moment spatial stencil, so both families run
    unchanged on the triangular mesh.
    """

    def __init__(self, xp, grid, D1, sigma_t, removal, order, bc=BC_ZERO_FLUX,
                 active=None, mask_bc=BC_VACUUM, op_cls=None, coeffs=None,
                 boundary_g=None, theta=None, symmetrize=False):
        coeffs = coeffs if coeffs is not None else _SDPN_C
        if order not in coeffs:
            raise ValueError(f"order must be one of {sorted(coeffs)}, got {order!r}")
        self.xp = xp
        op_cls = op_cls or GroupOperator
        c = coeffs[order]
        M = order + 1
        self.M = M
        self.order = order
        # symmetrize: conjugate the c tables by their diagonal similarity
        # (state V = diag(r) U, rows scaled by r) so the block becomes
        # symmetric and CG applies. The per-moment D and the (diagonal) Robin
        # boundary terms are similarity-invariant, so only the cell couplings
        # and the source/flux weight vectors change; the r_0 gauge cancels
        # between src_weights and phi0_weights. Not available with the coupled
        # Marshak boundary (its g matrix is not symmetrized by the scaling).
        if symmetrize:
            if boundary_g is not None:
                raise ValueError("symmetrize is incompatible with the coupled "
                                 "Marshak boundary")
            r = _diag_similarity(c)
            if r is None:
                raise ValueError(f"the order-{order} coefficient tables admit "
                                 "no diagonal symmetrizing similarity (use the "
                                 "non-symmetric form with BiCGStab)")
            c = [[[r[i] * c[m][i][j] / r[j] for j in range(M)]
                  for i in range(M)] for m in range(M)]

        def _is_sym(mat):
            return all(abs(mat[i][j] - mat[j][i])
                       <= 1e-12 * (abs(mat[i][j]) + abs(mat[j][i]) + 1e-300)
                       for i in range(M) for j in range(M))

        # True when the assembled block is symmetric (SPD up to physics):
        # symmetric tables and, if Marshak is on, a symmetric g (SPN's is;
        # K = g (diag(a)+g)^-1 diag(a) is then symmetric as well).
        self.symmetric = all(_is_sym(c[m]) for m in range(M)) and (
            boundary_g is None or _is_sym(boundary_g))
        # phi0 = c^(1)[0] . U ; isotropic source distributes by c^(1)[:, 0].
        self.phi0_weights = [c[0][0][j] for j in range(M)]
        self.src_weights = [c[0][i][0] for i in range(M)]
        # Backward-Euler time term theta = 1/(v*dt): a time derivative is
        # structurally a cross section that is equal in every even moment, so
        # in the U-form it transforms exactly like A with all Sigma_{2m-2}
        # replaced by theta -- the time matrix is theta * sum_m c^(m)
        # (``time_weights``; odd-moment time derivatives neglected, the
        # standard quasi-static closure of time-SPN kinetics). The driver adds
        # the matching source theta * time_weights . U_old per row.
        self.time_weights = [[sum(c[m][i][j] for m in range(M))
                              for j in range(M)] for i in range(M)]
        # Sigma_{2m-2}: m=1 -> removal (Sigma_0), m>=2 -> Sigma_t.
        sig_even = [removal] + [sigma_t] * (M - 1)

        def A(i, j):
            a = c[0][i][j] * sig_even[0]
            for m in range(1, M):
                cm = c[m][i][j]
                if cm != 0.0:
                    a = a + cm * sig_even[m]
            if theta is not None and self.time_weights[i][j] != 0.0:
                a = a + theta * self.time_weights[i][j]
            return a

        # Marshak vacuum (coupled boundary): the per-moment operators must NOT
        # carry their own vacuum leakage on those faces -- it is replaced by the
        # coupled -n.D grad U = (g (x) I) U term below -- so build them with the
        # vacuum faces made reflective.
        D_list = [D1 if i == 0 else 1.0 / ((4 * (i + 1) - 1) * sigma_t)
                  for i in range(M)]
        bc_mom = normalize_bc(bc)
        self.marshak = None
        if boundary_g is not None:
            bc_mom = _strip_vacuum(bc_mom)
        self.moments = [op_cls(xp, grid, D_list[i], A(i, i), bc=bc_mom,
                               active=active, mask_bc=mask_bc)
                        for i in range(M)]
        # Off-diagonal reaction coupling A_ij (i != j) is a cell term, so it
        # carries the same metric weight as the moment operators' removal.
        w = getattr(self.moments[0], "rhs_weight", None)
        self.coupling = {}
        for i in range(M):
            for j in range(M):
                if i != j:
                    a = A(i, j)
                    self.coupling[(i, j)] = a if w is None else a * w
        self.rhs_weight = w
        diag = xp.stack([m.diag for m in self.moments])   # (M, *grid)
        if boundary_g is not None:
            self.marshak = _marshak_faces(xp, grid, normalize_bc(bc), D_list,
                                          boundary_g)
            # Fold the coupled boundary's diagonal (i,i) into the Jacobi diagonal.
            for sl, K in self.marshak:
                for i in range(M):
                    diag[i][sl] = diag[i][sl] + K[..., i, i]
        self.inv_diag = 1.0 / diag

    def apply(self, u):
        """Return the SDPN block operator applied to u of shape (M, *grid)."""
        xp = self.xp
        out = xp.empty_like(u)
        for i in range(self.M):
            out[i] = self.moments[i].apply(u[i])
            for j in range(self.M):
                if i != j:
                    out[i] = out[i] + self.coupling[(i, j)] * u[j]
        if self.marshak is not None:
            # Coupled Marshak vacuum: row i += sum_j K_ij U_j on each vacuum-face
            # boundary layer (K = leakage-per-volume, reduces to the per-moment
            # Robin term when the moments decouple).
            for sl, K in self.marshak:
                us = xp.stack([u[j][sl] for j in range(self.M)], axis=-1)  # (*slab,M)
                corr = xp.matmul(K, us[..., None])[..., 0]                 # (*slab,M)
                for i in range(self.M):
                    out[i][sl] = out[i][sl] + corr[..., i]
        return out
