"""Matrix-free monolithic multigroup systems for implicit transient steps.

The production diffusion transient currently converges a fixed point over the
end-of-step fission source and performs Gauss--Seidel group solves inside each
map evaluation.  After analytic precursor elimination the very same step is a
single linear block system.  This module represents that system without
assembling a sparse ``(groups*cells)^2`` matrix and provides the current group
sweep as a flexible right preconditioner.

The classes are intentionally standalone while the method is evaluated.  They
do not alter :class:`ndgpu.transient.TransientSolver` or its validated default.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .linalg import PCGWorkspace, neumann_preconditioner, pcg


def _shape_of(operator):
    shape = getattr(operator, "shape", None)
    if shape is None:
        diag = getattr(operator, "inv_diag", None)
        if diag is None:
            raise TypeError("group operators must expose shape or inv_diag")
        shape = diag.shape
    return tuple(shape)


class MultigroupStepOperator:
    r"""Implicit diffusion step as one matrix-free block operator.

    For group ``g`` the row is

    .. math::

       L_g\phi_g - W\left[\sum_{h\ne g}\Sigma_{s,h\to g}\phi_h
       + {w_g\over k_0}\sum_h\nu\Sigma_{f,h}\phi_h\right],

    where ``L_g`` is the existing loss-plus-time group operator and ``W`` is
    its optional cylindrical finite-volume RHS weight.  ``w_g`` already
    contains prompt emission plus the analytically eliminated end-of-step
    precursor contribution.  Thus delayed and old-time sources belong only in
    the fixed right-hand side and the operator remains linear.

    Arrays have shape ``(groups, *cell_shape)``.  All coefficients stay on the
    backend selected by the supplied group operators.
    """

    def __init__(self, operators, sigma_s, nu_sigma_f, emission_weights,
                 k_eff, rhs_weight=None):
        self.operators = tuple(operators)
        self.groups = len(self.operators)
        if self.groups == 0:
            raise ValueError("at least one energy group is required")
        self.xp = self.operators[0].xp
        self.cell_shape = _shape_of(self.operators[0])
        if any(op.xp is not self.xp for op in self.operators):
            raise ValueError("all group operators must use the same backend")
        if any(_shape_of(op) != self.cell_shape for op in self.operators):
            raise ValueError("all group operators must have the same shape")
        if len(sigma_s) != self.groups or any(
                len(row) != self.groups for row in sigma_s):
            raise ValueError("sigma_s must be a square group-by-group table")
        if len(nu_sigma_f) != self.groups:
            raise ValueError("nu_sigma_f must contain one field per group")
        if len(emission_weights) != self.groups:
            raise ValueError("emission_weights must contain one field per group")
        if not np.isfinite(k_eff) or k_eff <= 0.0:
            raise ValueError("k_eff must be finite and positive")
        self.sigma_s = tuple(tuple(row) for row in sigma_s)
        self.nu_sigma_f = tuple(nu_sigma_f)
        self.emission_weights = tuple(emission_weights)
        self.k_eff = float(k_eff)
        self.rhs_weight = rhs_weight

        # A useful fallback diagonal for generic Krylov interfaces.  It includes
        # the same-group fission derivative; the GS preconditioner below is the
        # intended path and does not rely on this approximation.
        diagonal = []
        for g, op in enumerate(self.operators):
            diag = 1.0 / op.inv_diag
            fdiag = self.emission_weights[g] * self.nu_sigma_f[g] / self.k_eff
            if rhs_weight is not None:
                fdiag = rhs_weight * fdiag
            diagonal.append(diag - fdiag)
        self.inv_diag = 1.0 / self.xp.stack(diagonal)

    @property
    def shape(self):
        return (self.groups,) + self.cell_shape

    def _check_state(self, value):
        if tuple(value.shape) != self.shape:
            raise ValueError(f"multigroup state shape {value.shape} != {self.shape}")

    def fission_source(self, value):
        self._check_state(value)
        source = self.nu_sigma_f[0] * value[0]
        for g in range(1, self.groups):
            source = source + self.nu_sigma_f[g] * value[g]
        return source / self.k_eff

    def apply(self, value, out=None):
        """Return the coupled block product, optionally writing into ``out``."""
        self._check_state(value)
        if out is None:
            out = self.xp.empty_like(value)
        else:
            self._check_state(out)
        fission = self.fission_source(value)
        for g, op in enumerate(self.operators):
            op.apply(value[g], out=out[g])
            coupled = self.emission_weights[g] * fission
            for gf in range(self.groups):
                scatter = self.sigma_s[gf][g]
                if gf != g and scatter is not None:
                    coupled = coupled + scatter * value[gf]
            if self.rhs_weight is not None:
                coupled = self.rhs_weight * coupled
            out[g] -= coupled
        return out

    def fixed_rhs(self, inverse_velocity_dt, carried_flux, delayed_source):
        """Build ``W * (theta*phi_carried + delayed)`` for one step."""
        if not (len(inverse_velocity_dt) == len(carried_flux)
                == len(delayed_source) == self.groups):
            raise ValueError("fixed-source inputs need one entry per group")
        rows = []
        for g in range(self.groups):
            row = (inverse_velocity_dt[g] * carried_flux[g]
                   + delayed_source[g])
            if self.rhs_weight is not None:
                row = self.rhs_weight * row
            rows.append(row)
        return self.xp.stack(rows)


@dataclass
class GroupSweepStats:
    applications: int = 0
    group_solves: int = 0
    inner_iterations: int = 0


class EnergyGroupGaussSeidelPreconditioner:
    """Inexact energy-group sweep for flexible right preconditioning.

    Each application approximately solves the loss-plus-scatter block system.
    Lower-index groups use their newly computed values and higher-index groups
    use values from the preceding subsweep.  Optional lagged fission makes this
    the same source/group hierarchy as a production fixed-point evaluation;
    leaving it off lets outer FGMRES resolve fission globally and is usually
    safer near the critical pole.

    The group PCG tolerance is deliberately inexact.  FGMRES stores each
    resulting correction separately, so changing inner iteration counts do not
    violate its Krylov recurrence.
    """

    def __init__(self, block: MultigroupStepOperator, *, scatter_sweeps=1,
                 include_fission=False, inner_rtol=1e-2, inner_atol=0.0,
                 inner_maxiter=200, precond_degree=0):
        self.block = block
        self.xp = block.xp
        self.scatter_sweeps = int(scatter_sweeps)
        self.include_fission = bool(include_fission)
        self.inner_rtol = float(inner_rtol)
        self.inner_atol = float(inner_atol)
        self.inner_maxiter = int(inner_maxiter)
        if self.scatter_sweeps < 1:
            raise ValueError("scatter_sweeps must be positive")
        if self.inner_rtol < 0.0 or self.inner_atol < 0.0:
            raise ValueError("inner tolerances must be non-negative")
        if self.inner_maxiter < 1:
            raise ValueError("inner_maxiter must be positive")
        self.group_preconditioners = tuple(neumann_preconditioner(
            op.apply, op.inv_diag, int(precond_degree))
            for op in block.operators)
        templates = [self.xp.zeros(block.cell_shape,
                                   dtype=block.operators[0].inv_diag.dtype)
                     for _ in range(block.groups)]
        self.workspaces = tuple(PCGWorkspace.like(
            template, operator_out=True) for template in templates)
        self.stats = GroupSweepStats()

    def reset_stats(self):
        self.stats = GroupSweepStats()

    def __call__(self, residual):
        self.block._check_state(residual)
        z = self.xp.zeros_like(residual)
        for _ in range(self.scatter_sweeps):
            fission = (self.block.fission_source(z)
                       if self.include_fission else None)
            for g, op in enumerate(self.block.operators):
                q = residual[g].copy()
                coupled = None
                for gf in range(self.block.groups):
                    scatter = self.block.sigma_s[gf][g]
                    if gf != g and scatter is not None:
                        term = scatter * z[gf]
                        coupled = term if coupled is None else coupled + term
                if fission is not None:
                    term = self.block.emission_weights[g] * fission
                    coupled = term if coupled is None else coupled + term
                if coupled is not None:
                    if self.block.rhs_weight is not None:
                        coupled = self.block.rhs_weight * coupled
                    q += coupled
                solved, iterations = pcg(
                    op.apply, q, z[g], op.inv_diag, self.xp,
                    rtol=self.inner_rtol, atol=self.inner_atol,
                    maxiter=self.inner_maxiter,
                    precond=self.group_preconditioners[g],
                    workspace=self.workspaces[g], raise_on_fail=False)
                z[g] = solved
                self.stats.group_solves += 1
                self.stats.inner_iterations += iterations
        self.stats.applications += 1
        # The next application reuses group workspaces.  FGMRES must own this
        # particular preconditioned basis vector, so return independent storage.
        return z.copy()


class AdjointCoarseCorrectionPreconditioner:
    r"""Rank-one amplitude correction wrapped around a base preconditioner.

    Let ``p`` be a forward coarse mode, ``q`` its adjoint importance, and
    ``M^-1`` the energy-group sweep.  The adapted-deflation update

    .. math::

       \widetilde M^{-1}r = M^{-1}r +
       (p-M^{-1}Ap){q^T r\over q^T A p}

    makes the preconditioned operator exact on ``p`` while retaining the base
    action on the complementary space.  ``q`` supplies the physically relevant
    neutron-population coordinate instead of an unweighted Euclidean average.

    Setup costs one block apply and one base-preconditioner application. Every
    subsequent call adds only one adjoint dot product and one vector update; it
    does *not* duplicate the outer FGMRES block apply. The base may still be
    inexact/variable because the enclosing solver is flexible GMRES, although
    exactness on ``p`` is relative to the setup application of the base.
    """

    def __init__(self, block: MultigroupStepOperator, base, forward_mode,
                 adjoint_mode):
        self.block = block
        self.base = base
        self.xp = block.xp
        forward = self.xp.asarray(forward_mode)
        adjoint = self.xp.asarray(adjoint_mode)
        block._check_state(forward)
        block._check_state(adjoint)
        if not bool(self.xp.all(self.xp.isfinite(forward))):
            raise ValueError("forward coarse mode must be finite")
        if not bool(self.xp.all(self.xp.isfinite(adjoint))):
            raise ValueError("adjoint coarse mode must be finite")
        applied = block.apply(forward)
        denominator = float(self.xp.sum(adjoint * applied))
        scale = float(self.xp.sqrt(self.xp.sum(adjoint * adjoint))
                          * self.xp.sqrt(self.xp.sum(applied * applied)))
        if not np.isfinite(denominator) or abs(denominator) <= 1e-14 * max(scale, 1e-300):
            raise ValueError("adjoint coarse denominator q^T A p is singular")
        base_on_mode = base(applied)
        self.forward_mode = forward.copy()
        self.adjoint_mode = adjoint.copy()
        self.denominator = denominator
        self.direction = self.forward_mode - base_on_mode
        self.applications = 0

    def __call__(self, residual):
        self.block._check_state(residual)
        corrected = self.base(residual)
        coefficient = float(self.xp.sum(self.adjoint_mode * residual))
        corrected += (coefficient / self.denominator) * self.direction
        self.applications += 1
        return corrected


__all__ = [
    "MultigroupStepOperator",
    "EnergyGroupGaussSeidelPreconditioner",
    "AdjointCoarseCorrectionPreconditioner",
    "GroupSweepStats",
]
